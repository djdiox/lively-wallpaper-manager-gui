# Lively Dots Wallpaper

Interactive wallpaper for [Lively Wallpaper](https://livelywallpaper.net/).

Based on [glowing pastel dots](https://codepen.io/rachsmith/pen/eNgvvx) by [Rachel Smith](https://codepen.io/rachsmith).

## Installation

Download [Lively Wallpaper](https://livelywallpaper.net/).

Go to <https://github.com/RealCyGuy/lively-dots/releases/latest> and download the zip file.

Drag it into Lively.

Select it then you're happy!

## License

[MIT](https://github.com/RealCyGuy/lively-dots/blob/main/LICENSE.md)
